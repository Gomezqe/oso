package com.iquitosplay.roomsqlite.Interfaces;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;
import android.database.Cursor;

import com.iquitosplay.roomsqlite.Entidades.Persona;

import java.util.List;
//1.
@Dao
public interface PersonaDao {

    //aqui declaramos los metodos o las acciones para la bd
    //seleccionar cantidades
    @Query("SELECT COUNT(*) FROM " + Persona.TABLE_NAME)
    int count(); //metodo

//seleccionar todo
    @Query("SELECT * FROM "+Persona.TABLE_NAME)
    List<Persona> getAllUsuarios();


    //insertar
    @Insert
    void instarAll(Persona ... usuarios);

//eliminar
    @Query("DELETE FROM " + Persona.TABLE_NAME + " WHERE " + Persona.COLUMN_ID + " = :ide")
    int deleteById(long ide);

    //actualizar
    @Update
    int updateEntidad(Persona obj);


    //insertar 2
    @Insert
    long insert(Persona usuarios);



}
