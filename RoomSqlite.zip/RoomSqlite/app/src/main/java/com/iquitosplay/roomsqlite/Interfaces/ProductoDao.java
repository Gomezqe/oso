package com.iquitosplay.roomsqlite.Interfaces;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

import com.iquitosplay.roomsqlite.Entidades.Persona;
import com.iquitosplay.roomsqlite.Entidades.Producto;

import java.util.List;

@Dao
public interface ProductoDao {

    //aqui declaramos los metodos o las acciones para la bd
    //seleccionar cantidades
    @Query("SELECT COUNT(*) FROM " + Producto.TABLE_NAME)
    int count(); //metodo

    //seleccionar todo
    @Query("SELECT * FROM "+Producto.TABLE_NAME)
    List<Producto> getAllUsuarios();


    //insertar
    @Insert
    void instarAll(Producto ... usuarios);

    //eliminar
    @Query("DELETE FROM " + Producto.TABLE_NAME + " WHERE " + Producto.COLUMN_ID + " = :ide")
    int deleteById(long ide);

    //actualizar
    @Update
    int updateEntidad(Producto obj);


    //insertar 2
    @Insert
    long insert(Producto usuarios);
}
