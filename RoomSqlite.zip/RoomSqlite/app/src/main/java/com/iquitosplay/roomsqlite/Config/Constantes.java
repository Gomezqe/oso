package com.iquitosplay.roomsqlite.Config;

public class Constantes {
    public static String BD_NAME = "mibd"; //paso nro 2
}
