package com.iquitosplay.roomsqlite.Database;

import android.app.Person;
import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;
import android.support.annotation.VisibleForTesting;

import com.iquitosplay.roomsqlite.Entidades.Persona;
import com.iquitosplay.roomsqlite.Entidades.Producto;
import com.iquitosplay.roomsqlite.Interfaces.PersonaDao;
import com.iquitosplay.roomsqlite.Interfaces.ProductoDao;

//paso 1
@Database(entities = {Persona.class, Producto.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase{

    @SuppressWarnings("WeakerAccess")
    public abstract PersonaDao personaDao(); //que permisos va tener listar, eliminar, update, insertar

    public abstract ProductoDao productoDao(); //
    /**
     * The only instance
     */
    private static AppDatabase sInstance; //variable.

}
