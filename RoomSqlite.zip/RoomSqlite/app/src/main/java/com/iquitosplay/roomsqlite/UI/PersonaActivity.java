package com.iquitosplay.roomsqlite.UI;

import android.arch.persistence.room.Room;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;

import com.iquitosplay.roomsqlite.Database.AppDatabase;
import com.iquitosplay.roomsqlite.R;

public class PersonaActivity extends AppCompatActivity {

    EditText nombre;
    AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_persona);

      //  nombre = (EditText)findViewById(R.id.txtNombre);


        //llamamos a la bd
        db = Room.databaseBuilder(getApplicationContext(),AppDatabase.class,"produccion")
                .allowMainThreadQueries()
                .build();

    }
}
